package com.dyz.gameserver.msg.processor.common;
/**
 * 标志接口，实现此处理器的processor不需要验证
 * @author dyz
 *
 */
public interface INotAuthProcessor {

}
