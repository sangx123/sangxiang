package com.dyz.gameserver.sprite.base;

/**
 * 服务器中精灵接口
 *
 * @author  
 * @date 2016年6月30日 下午4:42:46
 * @version V1.0
 */
public interface GameObj {

	public void destroyObj();
}
